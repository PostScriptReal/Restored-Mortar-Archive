To install the mod, extract the contents of this zip file into the directory that Half-Life is located in, 
this can be found by clicking on the gear icon in the game's library page and clicking on 'Browse Local Files' in the 'Manage' dropdown.

Once that's done make sure you have the 'Allow custom addon content' option enabled, otherwise the game will load the regular map.
